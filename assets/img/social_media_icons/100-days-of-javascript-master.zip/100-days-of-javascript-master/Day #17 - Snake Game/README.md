# Day #17

### Snake Game
In this tutorial ([Open in Youtube](https://youtu.be/wM7eMJ26kc8)),  I am gonna showing to you how to code a snake game with javascript. this snake game is fully responsive and in touch devices it's have keys that user can use❗️

# Screenshot
Here we have project screenshot :


![screenshot](screenshot.jpg)