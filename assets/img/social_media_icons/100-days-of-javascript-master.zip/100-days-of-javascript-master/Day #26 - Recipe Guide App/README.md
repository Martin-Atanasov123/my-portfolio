# Day #26

### Recipe Guide App
In this tutorial ([Open in Youtube](https://youtu.be/KASIDsuSPnQ)),  I am gonna showing to you how to work with recipe api in javascript. we create a responsive recipe guide app in this video❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)
