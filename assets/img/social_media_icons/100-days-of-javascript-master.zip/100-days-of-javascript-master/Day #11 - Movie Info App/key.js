//Enter api key that recieved on your email here

key = "Your Api Key";