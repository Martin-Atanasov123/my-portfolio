# Day #24

### Simon Game
In this tutorial ([Open in Youtube](https://youtu.be/8g5nz_6kZW0)),  I am gonna showing to you how to code a simon game with javascript. this game's javascript code is fully commented❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)