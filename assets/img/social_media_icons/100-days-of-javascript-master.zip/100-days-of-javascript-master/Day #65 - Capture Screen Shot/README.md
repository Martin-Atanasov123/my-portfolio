# Day #65

### Capture Screenshot
In this tutorial ([Open in Youtube](https://youtu.be/uVzwT8UOla0)),  I am gonna showing to you how to take screenshot with javascript from webpage! we will use html2canvs library to take screenshots from website with javascript coding❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)