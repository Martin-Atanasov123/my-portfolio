# Day #3

### Password Generator
In this tutorial ([Open in Youtube](https://youtu.be/825u2Puaej0)),  I am gonna showing to you how to build a Password Generator with javascript. this pass generator also have different options to manage password creation❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)