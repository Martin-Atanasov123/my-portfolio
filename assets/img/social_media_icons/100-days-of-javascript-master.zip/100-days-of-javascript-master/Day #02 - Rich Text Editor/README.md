# Day #2

### Rich Text Editor
In this tutorial ([Open in Youtube](https://youtu.be/gRyvG7PZ4m0)),  I am gonna showing to you how to build a online text editor with javascript. this text editor is similar to microsoft office word❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)
