# Day #33

### Chrome Color Picker Extension
In this tutorial ([Open in Youtube](https://youtu.be/76fEOCaRLY0)),  In this tutorial, I am gonna showing to you how to code a chrome extension with javascript. we create a project that you can pick colors as a chrome extension with javascript❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)