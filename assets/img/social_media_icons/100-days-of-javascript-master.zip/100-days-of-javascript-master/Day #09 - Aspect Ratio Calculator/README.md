# Day #9

### Aspect Ratio Calculator
In this tutorial ([Open in Youtube](https://youtu.be/PitofaBtFxU)),  I am gonna showing to you how to code a simple Aspect ratio calculator with javascript. you can use this form in your sites or apps❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)