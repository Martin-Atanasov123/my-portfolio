# Day #27

### Mine Sweeper Game
In this tutorial ([Open in Youtube](https://youtu.be/Fv8wsgkQXrM)),  I am gonna showing to you how to create minesweeper game with javascript. we create this game with grids in css and javascript❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)