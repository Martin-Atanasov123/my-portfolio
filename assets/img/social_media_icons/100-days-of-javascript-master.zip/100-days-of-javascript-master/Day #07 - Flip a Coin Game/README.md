# Day #7

### Flip a Coin Game
In this tutorial ([Open in Youtube](https://youtu.be/-o-H1Ecqo_M)),  I am gonna showing to you how to code simple flip a coin game! this heads and tails game have very simple code and it's best js tutorial for beginners❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)