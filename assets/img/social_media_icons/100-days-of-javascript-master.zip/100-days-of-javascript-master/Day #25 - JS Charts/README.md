# Day #25

### Apex Chats
In this tutorial ([Open in Youtube](https://youtu.be/rOC_2DDAIPk)),  I am gonna showing to you how to work with charts in javascript. you can use this charts in your site dashboards❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)