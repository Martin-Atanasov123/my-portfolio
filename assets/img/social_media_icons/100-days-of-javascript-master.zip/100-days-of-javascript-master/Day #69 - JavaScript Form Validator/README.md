# Day #69

### JSON Parser
In this tutorial ([Open in YouTube](https://youtu.be/wzrHNx9WTFQ)), we will know how to validate form with javascript. we will use javascript functions to validate phone, email and other fields❗️

### 🌟 What You'll Learn:
- Understanding JS Functions: Learn how to use javascript functions!
- How to validate forms
- Working with html inputs

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)