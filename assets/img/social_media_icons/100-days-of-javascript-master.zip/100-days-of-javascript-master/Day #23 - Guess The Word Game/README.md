# Day #23

### Guess The Word Game
In this tutorial ([Open in Youtube](https://youtu.be/9uEaNSiXJeQ)),  I am gonna showing to you how to code a guess the word game with javascript. this game also is responsive❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)