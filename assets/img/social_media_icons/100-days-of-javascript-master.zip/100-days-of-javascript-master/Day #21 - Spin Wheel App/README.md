# Day #21

### Spin Wheel App
In this tutorial ([Open in Youtube](https://youtu.be/ZBHbmSfFPyk)),  I am gonna showing to you how to code a spin wheel app with javascript. you see this app in bet or lottery sites and also this design is full responsive❗️

# Screenshot
Here we have project screenshot :


![screenshot](screenshot.jpg)