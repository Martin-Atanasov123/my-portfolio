# Day #5

### Detect Device Battery
In this tutorial ([Open in Youtube](https://youtu.be/pXGVgEQntsA)),  I am gonna showing to you how to detect user device battery with javascript. you can use this online javascript battery detector to detect user device battery and detect if it's plugged charger or no❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)
