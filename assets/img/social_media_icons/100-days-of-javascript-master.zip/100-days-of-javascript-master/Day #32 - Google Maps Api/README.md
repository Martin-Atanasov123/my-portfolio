# Day #32

### Google Maps
In this tutorial ([Open in Youtube](https://youtu.be/g3IVpsF38S8)),  I am gonna showing to you how to use google maps api in javascript. we create a project that you can work with google map in javascript❗️Also this project is full responsive!

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)