# Day #42

### Live Code Editor
In this tutorial ([Open in Youtube](https://youtu.be/qKWpd-uneJg)), I am gonna showing to you how to code a code editor using JavaScript with CodeMirror library. in this video i'm using Code Mirror library with it's settings to create a code editor with live code preview. Also this code is fully responsive and we can change it's theme, this code is codepen site clone❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.png)
