# Day #28

### Github Api
In this tutorial ([Open in Youtube](https://youtu.be/M6p5ybSsVq4)),  I am gonna showing to you how to use github api in javascript. we create a project that you can search github usernames and see their details with javascript❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)