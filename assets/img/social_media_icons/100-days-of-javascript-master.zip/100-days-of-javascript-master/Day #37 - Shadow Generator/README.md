# Day #37

### Box Shadow Generator
In this tutorial ([Open in Youtube](https://youtu.be/m31q1Aorkkc)),  I am gonna showing to you how to code a css box shadow generator with javascript. we create a project that you can generate css box shadow styles and project show you the generated shadow style codes and you can copy and use it in your site designs❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)