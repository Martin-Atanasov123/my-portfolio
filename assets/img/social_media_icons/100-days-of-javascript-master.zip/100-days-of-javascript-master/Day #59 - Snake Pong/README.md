# Day #59

### Snake Pong Game
In this tutorial ([Open in Youtube](https://youtu.be/jyhtQSjEP4s)),  I am gonna showing to you how to combine snake and pong game with javascript! we will code a snake game but food moves as pong game, this javascript project is very good for who one need javascript project with logic

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)