# Day #16

### Geometric Art Generator
In this tutorial ([Open in Youtube](https://youtu.be/Kn-nFPT9Qcs)),  I am gonna showing to you how to code a Geometric Art Generator with Javascript. this code will generate different geometric arts with divs, we didn't used any image in this code❗️

# Screenshot
Here we have project screenshot :


![screenshot](screenshot.jpg)