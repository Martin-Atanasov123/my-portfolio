# Day #14

### Crypto Price App
In this tutorial ([Open in Youtube](https://youtu.be/AZaZOP2sX7Y)),  I am gonna showing to you how to code a crypto price app with javascript. in this tutorial also we use coingecko api and we get data from api❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)
