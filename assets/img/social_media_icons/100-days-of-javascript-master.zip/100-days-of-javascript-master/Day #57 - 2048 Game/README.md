# Day #57

### 2048 Game
In this tutorial ([Open in Youtube](https://youtu.be/rWNHIUjfsvw)),  I am gonna showing to you how to code a javascript 2048 game with most simple logic in the world! Also we will use css grids for design, flexbox and some animations for it❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)