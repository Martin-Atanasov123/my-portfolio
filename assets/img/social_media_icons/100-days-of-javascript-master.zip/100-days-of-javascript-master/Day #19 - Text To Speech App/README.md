# Day #19

### Text To Speech App
In this tutorial ([Open in Youtube](https://youtu.be/QzmKDr-8n90)),  I am gonna showing to you how to code a text to speech app with javascript. this text to speech is fully responsive and you can use it in your sites❗️

# Screenshot
Here we have project screenshot :


![screenshot](screenshot.jpg)
