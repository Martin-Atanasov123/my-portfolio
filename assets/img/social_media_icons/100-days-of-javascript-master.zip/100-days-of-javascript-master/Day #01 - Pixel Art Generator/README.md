# Day #1

### Pixel Art Generator
In this tutorial ([Open in Youtube](https://youtu.be/DfDPJqD3FjI)), I am gonna showing to you how to build a pixel art generator project with javascript. you can call it pixel paint app too❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)