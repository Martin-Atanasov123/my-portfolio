# Day #6

### XO Game
In this tutorial ([Open in Youtube](https://youtu.be/MgtGHfdpigU)),  I am gonna showing to you how to create simple javascript xo game! this tic tac toe game have very simple code and it's best js tutorial for beginners❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)