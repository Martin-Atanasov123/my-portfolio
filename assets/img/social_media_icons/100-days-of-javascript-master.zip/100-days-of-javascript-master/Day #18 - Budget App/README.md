# Day #18

### Budget App
In this tutorial ([Open in Youtube](https://youtu.be/G_Prk9-G2Q0)),  I am gonna showing to you how to code a budget app with javascript. this budget app is fully responsive and you can use it in your web projects❗️

# Screenshot
Here we have project screenshot :


![screenshot](screenshot.jpg)