# Day #8

### Multi Step Form
In this tutorial ([Open in Youtube](https://youtu.be/DRJasSDpRHg)),  I am gonna showing to you how to code a simple multistep form with javascript. you can use this form in your site to get user data❗️
this form also is responsive!

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)