# Day #40

### Detect Internet Speed
In this tutorial ([Open in Youtube](https://youtu.be/Tvr0m1Wa4RM)), I am gonna showing to you how to code a Internet Speed Test using JavaScript. in this video we Detect Internet Speed with downloading images from unsplash api and calculating image download time depending on it's size❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)
