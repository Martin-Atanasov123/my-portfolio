# Day #43

### Parallex Slider With Flickity
In this tutorial ([Open in Youtube](https://youtu.be/8WUajxQa-bw)), I am gonna showing to you how to use flickity library in javascript to create a Parallex Slider. Also this slider is full responsive and you can use it as carousel in your website designs❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)
