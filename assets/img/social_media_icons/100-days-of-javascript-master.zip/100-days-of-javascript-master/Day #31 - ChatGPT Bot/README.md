# Day #31

### ChatGPT Bot
In this tutorial ([Open in Youtube](https://youtu.be/xsNKwwhKfRI)),  I am gonna showing to you how to use chatgpt api to code a chatgpt bot with javascript. we create a project that you can ask anything from chatgpt with javascript❗️
Also we use Rapidapi in this bot too! we use official chatgpt api.

## Warning
You need to get your own api key (in video we showed how!) and replace it in index.js file on line 46 :

```javascript
'X-RapidAPI-Key': 'Your Key',
```


# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)